import os
import django
import sys

# 添加项目根目录到 Python 路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 设置 Django 环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

# 现在可以导入 Django 相关模块
from data.tasks import update_crypto_prices
from data.services import CryptoDataService
from celery.result import AsyncResult


def test_task_directly():
	"""
	直接测试任务函数，不通过 Celery
	"""
	print("=== 直接测试任务函数 ===")
	try:
		# 直接调用任务函数（同步执行）
		result = update_crypto_prices()
		print(f"任务执行结果: {result}")
	except Exception as e:
		print(f"任务执行失败: {e}")
		import traceback
		traceback.print_exc()


def test_service_directly():
	"""
	直接测试服务层函数
	"""
	print("\n=== 直接测试服务层 ===")
	try:
		symbols = ['BTC', 'ETH']
		data = CryptoDataService.fetch_crypto_data(symbols)
		print(f"获取到的数据: {data}")

		if data:
			CryptoDataService.update_database(data)
			print("数据成功更新到数据库")
		else:
			print("没有获取到数据")
	except Exception as e:
		print(f"服务层测试失败: {e}")
		import traceback
		traceback.print_exc()


def test_task_via_celery():
	"""
	通过 Celery 异步测试任务
	"""
	print("\n=== 通过 Celery 测试任务 ===")
	try:
		# 异步调用任务
		result = update_crypto_prices.delay()
		print(f"任务已提交，ID: {result.id}")

		# 等待任务完成（同步等待，仅用于测试）
		task_result = result.get(timeout=30)
		print(f"任务执行结果: {task_result}")

		# 检查任务状态
		print(f"任务状态: {result.status}")

	except Exception as e:
		print(f"Celery 任务测试失败: {e}")
		import traceback
		traceback.print_exc()


if __name__ == "__main__":
	# 按顺序运行测试
	test_service_directly()  # 先测试服务层
	test_task_directly()  # 再测试任务（同步）
	test_task_via_celery() # 最后测试 Celery 异步（需要 Redis 运行）