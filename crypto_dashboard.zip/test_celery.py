import os
import sys
import subprocess


def verify_celery_fix():
	print("=== 验证Celery修复 ===")

	# 测试1: 检查是否能导入
	print("1. 测试导入...")
	try:
		project_root = os.path.dirname(os.path.abspath(__file__))
		sys.path.insert(0, project_root)
		os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')

		import django
		django.setup()

		from data.tasks import update_crypto_prices
		print("✓ 导入成功")
	except Exception as e:
		print(f"✗ 导入失败: {e}")
		return False

	# 测试2: 检查Celery应用
	print("2. 测试Celery应用...")
	try:
		from core.celery import app
		print("✓ Celery应用加载成功")
	except Exception as e:
		print(f"✗ Celery应用加载失败: {e}")
		return False

	# 测试3: 尝试启动worker（短暂运行）
	print("3. 测试worker启动...")
	try:
		# 只运行2秒然后停止
		process = subprocess.Popen([
			'celery', '-A', 'core', 'worker', '--loglevel=info', '--concurrency=1'
		], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

		# 等待2秒
		import time
		time.sleep(2)

		# 终止进程
		process.terminate()
		process.wait(timeout=5)
		print("✓ Worker启动测试通过")
	except Exception as e:
		print(f"✗ Worker启动测试失败: {e}")
		return False

	print("🎉 所有测试通过！Celery应该可以正常工作了")
	return True


if __name__ == "__main__":
	verify_celery_fix()