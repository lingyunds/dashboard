from rest_framework import viewsets
from .models import CryptoCurrency
from .serializers import CryptoCurrencySerializer
from rest_framework import status
from rest_framework.response import Response

class CurrencyViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API端点：列出所有加密货币及其最新价格。
    """
    queryset = CryptoCurrency.objects.all().prefetch_related('price_history')
    serializer_class = CryptoCurrencySerializer

    # def list(self, request, *args, **kwargs):
    #     queryset = self.get_queryset()
    #     serializer = self.get_serializer(queryset, many=True)
    #
    #     return Response(serializer.data, status=status.HTTP_200_OK)