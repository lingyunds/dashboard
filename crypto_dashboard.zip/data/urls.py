#!/usr/bin/env python
# -*- coding: utf-8 -*-
# products/urls.py

from django.urls import re_path
from .views import CurrencyViewSet

price_history = CurrencyViewSet.as_view({
    'get': 'list',
})


urlpatterns = [
	re_path(r'^lastest_price/$', price_history),

]
